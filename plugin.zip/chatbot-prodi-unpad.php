<?php
/**
 * Plugin Name:       Chatbot Program Studi Unpad
 * Plugin URI:        https://pipp.unpad.ac.id
 * Description:       Chatbot AI Akademik untuk Program Studi Universitas Padjadjaran. Gunakan shortcode [prodi_chatbot] atau [prodi_chatbot mode="floating"].
 * Version:           1.3.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Pusat Inovasi Pengajaran dan Pembelajaran (PIPP) Universitas Padjadjaran
 * Author URI:        https://pipp.unpad.ac.id
 * License:           MIT
 * Text Domain:       chatbot-prodi-unpad
 */

defined( 'ABSPATH' ) || exit;

define( 'PRODI_CHATBOT_VERSION',     '1.3.0' );
define( 'PRODI_CHATBOT_PLUGIN_FILE', __FILE__ );
define( 'PRODI_CHATBOT_DIR',         plugin_dir_path( __FILE__ ) );
define( 'PRODI_CHATBOT_URL',         plugin_dir_url( __FILE__ ) );
define( 'PRODI_CHATBOT_ASSETS_URL',  PRODI_CHATBOT_URL . 'assets/' );

require_once PRODI_CHATBOT_DIR . 'includes/class-chatbot-admin.php';
require_once PRODI_CHATBOT_DIR . 'includes/class-chatbot-widget.php';

add_action( 'plugins_loaded', function () {
    new PRODI_Chatbot_Admin();
    new PRODI_Chatbot_Widget();
} );

register_activation_hook( __FILE__, function () {
    $defaults = [
        'prodi_chatbot_enabled'       => '1',
        'prodi_chatbot_api_url'       => 'http://localhost:5000',
        'prodi_chatbot_ws_url'        => 'ws://localhost:8080/ws',
        'prodi_chatbot_bot_name'      => 'Asisten Program Studi Unpad',
        'prodi_chatbot_bot_subtitle'  => 'Universitas Padjadjaran',
        'prodi_chatbot_logo_url'      => '',
        'prodi_chatbot_default_lang'  => 'id',
        'prodi_chatbot_default_mode'  => 'embedded',
        'prodi_chatbot_chat_height'   => '650px',
    ];
    foreach ( $defaults as $k => $v ) add_option( $k, $v );
} );

register_deactivation_hook( __FILE__, function () {
    delete_transient( 'prodi_chatbot_health_api' );
    delete_transient( 'prodi_chatbot_health_ws' );
} );
