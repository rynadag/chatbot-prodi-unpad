<?php
defined( 'ABSPATH' ) || exit;

class PRODI_Chatbot_Widget {

    public function __construct() {
        add_shortcode( 'prodi_chatbot', [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );
    }

    public function register_assets() {
        wp_register_style(
            'prodi-chatbot-frontend',
            PRODI_CHATBOT_ASSETS_URL . 'css/chatbot-frontend.css',
            [],
            PRODI_CHATBOT_VERSION
        );
        wp_register_script(
            'prodi-chatbot-frontend',
            PRODI_CHATBOT_ASSETS_URL . 'js/chatbot-frontend.js',
            [],
            PRODI_CHATBOT_VERSION,
            true
        );

        $logo = get_option( 'prodi_chatbot_logo_url', '' );
        if ( empty( $logo ) ) {
            $logo = PRODI_CHATBOT_ASSETS_URL . 'images/prodi-logo-default.svg';
        }

        wp_localize_script( 'prodi-chatbot-frontend', 'prodiChatbotConfig', [
            'apiUrl'      => esc_url_raw( get_option( 'prodi_chatbot_api_url',      'http://localhost:5000' ) ),
            'wsUrl'       => sanitize_text_field( get_option( 'prodi_chatbot_ws_url', 'ws://localhost:8080/ws' ) ),
            'botName'     => sanitize_text_field( get_option( 'prodi_chatbot_bot_name',     'Asisten Program Studi Unpad' ) ),
            'botSubtitle' => sanitize_text_field( get_option( 'prodi_chatbot_bot_subtitle', 'Universitas Padjadjaran' ) ),
            'logoUrl'     => esc_url( $logo ),
            'defaultLang' => sanitize_text_field( get_option( 'prodi_chatbot_default_lang', 'id' ) ),
            'chatHeight'  => sanitize_text_field( get_option( 'prodi_chatbot_chat_height',  '650px' ) ),
        ] );
    }

    public function render_shortcode( $atts ) {
        // Respect the enabled toggle
        if ( get_option( 'prodi_chatbot_enabled', '1' ) !== '1' ) {
            return '';
        }

        $atts = shortcode_atts( [
            'mode'   => get_option( 'prodi_chatbot_default_mode', 'embedded' ),
            'lang'   => '',
            'height' => '',
        ], $atts, 'prodi_chatbot' );

        $mode   = in_array( $atts['mode'], [ 'embedded', 'floating' ], true ) ? $atts['mode'] : 'embedded';
        $lang   = in_array( $atts['lang'], [ 'id', 'en' ], true ) ? $atts['lang'] : '';
        $height = ! empty( $atts['height'] ) ? sanitize_text_field( $atts['height'] ) : '';

        wp_enqueue_style( 'prodi-chatbot-frontend' );
        wp_enqueue_script( 'prodi-chatbot-frontend' );

        static $n = 0; $n++;
        $uid = 'prodi-chatbot-' . $n . '-' . substr( md5( uniqid() ), 0, 6 );

        $data  = 'data-mode="' . esc_attr( $mode ) . '"';
        if ( $lang )   $data .= ' data-lang="'   . esc_attr( $lang )   . '"';
        if ( $height ) $data .= ' data-height="' . esc_attr( $height ) . '"';

        return '<div id="' . esc_attr( $uid ) . '" class="prodi-chatbot-root" ' . $data . '></div>';
    }
}
